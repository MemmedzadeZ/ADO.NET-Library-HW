﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Author : BaseEntity
{
    public string FirstName { get; set; }   
    public string LastName { get; set; }


    public virtual ICollection<Book> Books { get; set; }

}