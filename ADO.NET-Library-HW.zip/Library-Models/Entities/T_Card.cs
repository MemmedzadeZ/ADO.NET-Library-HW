﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class T_Card : BaseEntity
{
    public DateTime DateOut { get; set; }   
    public DateTime DateIn { get; set; }

    public virtual int TeacherId { get; set; }
    public virtual int BookId { get; set; }
    public virtual int LibrayId { get; set; }


}
