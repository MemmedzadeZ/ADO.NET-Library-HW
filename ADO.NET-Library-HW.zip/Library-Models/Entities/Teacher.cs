﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Teacher:BaseEntity
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public virtual int DepartmentId { get; set; }

    public virtual ICollection<T_Card> T_Cards { get; set; }

}
