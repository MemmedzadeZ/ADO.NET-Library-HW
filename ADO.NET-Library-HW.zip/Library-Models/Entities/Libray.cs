﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Libray:BaseEntity
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public virtual ICollection<S_Card> S_Cards { get; set; }
    public virtual ICollection<T_Card> T_Cards { get; set; }

}
