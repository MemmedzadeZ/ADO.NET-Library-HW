﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Student :BaseEntity
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Term { get; set; }
    public virtual int GroupId { get; set; }

    public virtual ICollection<S_Card> S_Cards { get; set; }
}
