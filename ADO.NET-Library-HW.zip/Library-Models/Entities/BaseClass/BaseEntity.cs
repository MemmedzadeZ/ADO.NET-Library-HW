﻿namespace Library_Models.Entities.BaseClass;

public class BaseEntity
{
    public int Id { get; set; } 
}
