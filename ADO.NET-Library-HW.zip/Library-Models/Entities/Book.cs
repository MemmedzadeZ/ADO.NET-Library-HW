﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Book : BaseEntity
{

    public string Name { get; set; }
    public int Pages { get; set; }
    public int YearPress { get; set; }
    public string Comment { get; set; }
    public int Quantity { get; set; }


    //Forign Key
    public virtual int ThemId { get; set; }
    public virtual int CategoryId { get; set; }
    public virtual int AuthorId { get; set; }
    public virtual int PressId { get; set; }
    public virtual ICollection<S_Card> S_Cards { get; set; }
    public virtual ICollection<T_Card> T_Cards { get; set; }


}
