﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Press : BaseEntity
{
    public string Name { get; set; }
    public virtual ICollection<Book> Books { get; set; }

}
