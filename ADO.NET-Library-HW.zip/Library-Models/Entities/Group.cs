﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Group :BaseEntity
{
    public string Name { get; set; }

    public virtual int FacultyId { get; set; }

    public virtual ICollection<Student> Students { get; set; }

}
