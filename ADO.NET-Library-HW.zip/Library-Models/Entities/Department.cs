﻿using Library_Models.Entities.BaseClass;

namespace Library_Models.Entities;

public class Department:BaseEntity
{

    public string Name { get; set; }

    public virtual ICollection<Teacher> Teachers { get; set; }


}
