﻿using Library_Models.Entities;

namespace Library_DataAccess.Repositories.Abstructs;

public interface IT_CardRepository : IBaseRepository<T_Card>
{
}
