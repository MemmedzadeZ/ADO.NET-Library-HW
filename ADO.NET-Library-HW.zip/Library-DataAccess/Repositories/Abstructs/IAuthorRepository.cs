﻿using Library_Models.Entities;

namespace Library_DataAccess.Repositories.Abstructs;


public interface IAuthorRepository : IBaseRepository<Author>
{
}
