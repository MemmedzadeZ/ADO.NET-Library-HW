﻿namespace Library_DataAccess.Repositories.Concrets;

public class T_CardRepository
{
}
