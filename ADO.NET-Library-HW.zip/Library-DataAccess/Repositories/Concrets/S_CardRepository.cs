﻿namespace Library_DataAccess.Repositories.Concrets;

public class S_CardRepository
{
}
