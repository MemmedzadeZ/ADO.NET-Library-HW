﻿namespace Library_DataAccess.Repositories.Concrets;

public class PressRepository
{
}
