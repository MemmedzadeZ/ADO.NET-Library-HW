﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace Library_DataAccess.Contexts;

public class LibraryContext:DbContext
{

    string strCon = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder
            .UseLazyLoadingProxies()
            .UseSqlServer(strCon);

        base.OnConfiguring(optionsBuilder);
    }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
        base.OnModelCreating(modelBuilder);
    }



    public virtual DbSet<Author> Authors { get; set; }
    public virtual DbSet<Book> Books { get; set; }
    public virtual DbSet<Category> Categories { get; set; }
    public virtual DbSet<Department> Departments { get; set; }
    public virtual DbSet<Faculty> Faculties { get; set; }
    public virtual DbSet<Group> Groups { get; set; }
    public virtual DbSet<Libray> Librays { get; set; }
    public virtual DbSet<Press> Presses { get; set; }
    public virtual DbSet<S_Card> S_Cards { get; set; }
    public virtual DbSet<Student> Students { get; set; }
    public virtual DbSet<T_Card> T_Cards { get; set; }
    public virtual DbSet<Teacher> Teachers { get; set; }
    public virtual DbSet<Them> Thems { get; set; }


}
