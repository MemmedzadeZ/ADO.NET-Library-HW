﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Library_DataAccess.Configurations;

internal class ThemConfiguration : IEntityTypeConfiguration<Them>
{
    public void Configure(EntityTypeBuilder<Them> builder)
    {
        builder.HasKey(  t => t.Id);
        builder.Property(t => t.Id).UseIdentityColumn();
        builder.Property(t => t.Name).HasMaxLength(50).IsRequired();
    }
}
