﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Library_DataAccess.Configurations;

internal class GroupConfiguration : IEntityTypeConfiguration<Group>
{
    public void Configure(EntityTypeBuilder<Group> builder)
    {
        builder.HasKey(  g => g.Id);
        builder.Property(g => g.Id).UseIdentityColumn();
        builder.Property(g => g.Name).HasMaxLength(50).IsRequired();
    }
}
