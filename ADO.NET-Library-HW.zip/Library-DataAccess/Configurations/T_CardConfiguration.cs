﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Library_DataAccess.Configurations;

internal class T_CardConfiguration : IEntityTypeConfiguration<T_Card>
{

    public void Configure(EntityTypeBuilder<T_Card> builder)
    {

        builder.HasKey(  tc => tc.Id);
        builder.Property(tc => tc.Id).UseIdentityColumn();
        builder.Property(tc => tc.DateIn).HasColumnType("date");
        builder.Property(tc => tc.DateOut).HasColumnType("date");
    }
}

