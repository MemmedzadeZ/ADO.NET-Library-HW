﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_DataAccess.Configurations
{
    internal class S_CardConfiguration : IEntityTypeConfiguration<S_Card>
    {
        public void Configure(EntityTypeBuilder<S_Card> builder)
        {
            builder.HasKey(  sc => sc.Id);
            builder.Property(sc => sc.Id).UseIdentityColumn();
            builder.Property(sc => sc.DateIn).HasColumnType("date");
            builder.Property(sc => sc.DateOut).HasColumnType("date");

        }
    }
}
