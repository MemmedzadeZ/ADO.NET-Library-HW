﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Library_DataAccess.Configurations;

internal class LibrayConfiguration : IEntityTypeConfiguration<Libray>
{
    public void Configure(EntityTypeBuilder<Libray> builder)
    { 
        builder.HasKey(  l => l.Id);
        builder.Property(l => l.Id).UseIdentityColumn();
        builder.Property(l => l.FirstName).HasMaxLength(50).IsRequired();
        builder.Property(l => l.LastName).HasMaxLength(50).IsRequired();
    }
}
