﻿using Library_Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Library_DataAccess.Configurations;

internal class DepartmentConfiguration : IEntityTypeConfiguration<Department>
{
    public void Configure(EntityTypeBuilder<Department> builder)
    {
        builder.HasKey(  d => d.Id);
        builder.Property(d => d.Id).UseIdentityColumn();
        builder.Property(d => d.Name).HasMaxLength(50).IsRequired();
    }
}
